export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCf9a4tenV6SZ_R1vmsG0pkc6X3TlIhJ7o",
    authDomain: "keepit-amarquez.firebaseapp.com",
    databaseURL: "https://keepit-amarquez.firebaseio.com",
    projectId: "keepit-amarquez",
    storageBucket: "keepit-amarquez.appspot.com",
    messagingSenderId: "636577110862",
    appId: "1:636577110862:web:89d0207d3a5df576f35c1f"
  }
};
