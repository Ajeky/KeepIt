export interface Nota {
    titulo: string;
    descripcion: string;
    categoria: string;
}
