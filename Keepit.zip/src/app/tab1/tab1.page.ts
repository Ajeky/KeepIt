import { Component } from '@angular/core';
import { Nota } from '../models/nota.interface';
import { FirestoreResponse } from '../models/firestore-response.interface';
import { NotasService } from '../services/notas.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  listaNotas: FirestoreResponse<Nota>[];

  constructor(
    private notasServicio: NotasService
  ) {}

}
